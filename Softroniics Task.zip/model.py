import joblib

# Load trained model and vectorizer
model = joblib.load("spam_ham_model (1).pkl")
vectorizer = joblib.load("tfidf_vectorizer.pkl")

def predict_email(email_text):
    email_tfidf = vectorizer.transform([email_text])
    prediction = model.predict(email_tfidf)[0]
    return "Spam" if prediction == 1 else "Ham"
